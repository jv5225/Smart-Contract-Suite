const fs = require("fs");
const { execSync } = require("child_process");

const filename = process.argv[2];
if (!filename) {
  console.error("Usage: node index.js <contract-file>");
  process.exit(1);
}

let rawOutput;
try {
  rawOutput = execSync(`slither ${filename}`, { encoding: "utf-8" });
} catch (err) {
  rawOutput = err.stdout || err.stderr || err.message;
}

// === Extract Slither Score Section ===
const scoreMatch = rawOutput.match(/Security Score:\s*(\S+)/);
const score = scoreMatch ? scoreMatch[1] : "N/A";

// === Extract Risk Findings Section ===
const riskStart = rawOutput.indexOf("=== Principal Protection Report ===");
const riskEnd = rawOutput.indexOf("=== Raw Slither Output ===");
const riskSection = riskStart !== -1 && riskEnd !== -1
  ? rawOutput.slice(riskStart, riskEnd).trim()
  : "No risk section found";

// === Structure Risks in JSON ===
const riskLines = riskSection
  .split("\n")
  .filter(line => line.trim().startsWith("-"))
  .map(line => {
    const message = line.replace(/^- /, "").trim();
    const severity = message.includes("(Critical)") ? "Critical"
                  : message.includes("(High)")     ? "High"
                  : message.includes("(Medium)")   ? "Medium"
                  : message.includes("(Low)")      ? "Low"
                  : "Info";
    return { severity, message };
  });

// === Format Markdown ===
const md = `# Smart Contract Risk Report

**File:** ${filename}  
**Score:** ${score}  
**Date:** ${new Date().toISOString()}

## Findings
${riskLines.length === 0 ? "_No risks detected._" :
  riskLines.map(r => `- **${r.severity}**: ${r.message}`).join("\n")}
`;

// === Format JSON ===
const json = {
  file: filename,
  score,
  timestamp: new Date().toISOString(),
  risks: riskLines
};

// === Format Plain Text ===
const txt = `${riskSection}\n\n---- Raw Slither Output ----\n${rawOutput}`;

// === Write Files ===
fs.writeFileSync("report.txt", txt);
fs.writeFileSync("report.md", md);
fs.writeFileSync("report.json", JSON.stringify(json, null, 2));

console.log("✅ Reports saved: report.txt, report.md, report.json");


